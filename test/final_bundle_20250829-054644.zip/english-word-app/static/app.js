function $(id){return document.getElementById(id)}
function today(){const d=new Date();const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),da=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${da}`}
const regDateEl=$("regDate");if(regDateEl)regDateEl.value=today();
/* 전체 JS 로직: 등록/조회/삭제/퀴즈/통계 등... 개선된 버전 */ 
