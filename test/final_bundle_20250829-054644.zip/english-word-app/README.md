# English Word App

설치: pip install -r requirements.txt

실행: python main.py
