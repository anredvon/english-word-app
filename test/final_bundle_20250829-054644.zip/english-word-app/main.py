import os,pymysql
from flask import Flask,request,jsonify,render_template,send_from_directory
app=Flask(__name__)
DB={"host":"anredvon.mysql.pythonanywhere-services.com","user":"anredvon","password":os.environ.get("DB_PASS",""),"database":"anredvon$default","charset":"utf8mb4","cursorclass":pymysql.cursors.DictCursor}
def get_conn(): return pymysql.connect(**DB)
@app.route("/")
def home(): return render_template("index.html")
@app.get("/api/words")
def list_words():
    with get_conn() as c,c.cursor() as cur:
        cur.execute("SELECT * FROM words ORDER BY id DESC")
        return jsonify(cur.fetchall())
if __name__=='__main__':app.run(host="0.0.0.0",port=3000,debug=True)
